package br.com.leosilvadev.pizzaria.modelo.enumeracoes;

public enum CategoriaDePizza {
	
	BROTINHO, MEDIA, GRANDE

}
