package br.com.leosilvadev.pizzaria.modelo.enumeracoes;

public enum CategoriaDeIngrediente {

	FRIOS, SALADA, CARNE
	
}
