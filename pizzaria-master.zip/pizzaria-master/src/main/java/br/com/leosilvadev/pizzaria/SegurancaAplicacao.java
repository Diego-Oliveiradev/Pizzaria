package br.com.leosilvadev.pizzaria;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SegurancaAplicacao extends AbstractSecurityWebApplicationInitializer {

}
